// Greeting di halaman Home
if (document.getElementById("greeting")) {
    let nama = prompt("Masukkan nama Anda:");
    document.getElementById("greeting").textContent = "Hi, " + nama + "!";
}

// Validasi Formulir
if (document.getElementById("contactForm")) {
    document.getElementById("contactForm").addEventListener("submit", function(event) {
        event.preventDefault();

        let nama = document.getElementById("nama").value;
        let email = document.getElementById("email").value;
        let pesan = document.getElementById("pesan").value;

        if (nama === "" || email === "" || pesan.length < 10) {
            alert("Isi semua data dengan benar!");
            return;
        }

        document.getElementById("output").innerHTML = `
            <h3>Data yang Anda kirim:</h3>
            <p>Nama: ${nama}</p>
            <p>Email: ${email}</p>
            <p>Pesan: ${pesan}</p>
        `;
    });
}
